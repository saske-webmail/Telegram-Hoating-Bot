<?php
/**
 * GitFlow Code Console v20.1 - SYNTAX FIXED
 */
session_start();
if (!isset($_SESSION['token']) || !isset($_GET['repo']) || !isset($_GET['file'])) {
    header('Location: dashboard.php');
    exit;
}

$token = $_SESSION['token'];
$user  = $_SESSION['user']['login'];
$repo  = $_GET['repo'];
$file  = $_GET['file'];

// --- FETCH FILE CONTENT ---
$api_url = "https://api.github.com/repos/$user/$repo/contents/" . str_replace(' ', '%20', $file);
$ch = curl_init($api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer $token", "User-Agent: GitFlow-Console"]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$res = json_decode(curl_exec($ch), true);
curl_close($ch);

$content = isset($res['content']) ? base64_decode($res['content']) : '';
$sha = $res['sha'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Edit: <?php echo basename($file); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --bg: #000; --border: #1a1a1a; --text: #fff; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: var(--bg); color: var(--text); font-family: 'JetBrains Mono', monospace; overflow: hidden; }
        header { height: 60px; border-bottom: 1.5px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 15px; }
        .back { color: #555; text-decoration: none; font-size: 1.2rem; }
        .save-btn { background: #fff; color: #000; border: none; padding: 8px 15px; border-radius: 4px; font-weight: 800; font-size: 0.7rem; }
        .editor-container { height: calc(100vh - 110px); width: 100%; }
        textarea { width: 100%; height: 100%; background: transparent; color: #ccc; border: none; outline: none; padding: 20px; font-size: 13px; line-height: 1.6; resize: none; white-space: pre; overflow: auto; }
        .toolbar { height: 50px; border-top: 1.5px solid var(--border); display: flex; align-items: center; padding: 0 10px; gap: 5px; overflow-x: auto; background: #050505; }
        .tool-btn { background: #0a0a0a; border: 1px solid var(--border); color: #fff; padding: 8px 12px; border-radius: 4px; font-size: 0.7rem; }
        #loader { position: fixed; inset: 0; background: rgba(0,0,0,0.8); display: none; align-items: center; justify-content: center; z-index: 9999; flex-direction: column; }
        .spin { width: 30px; height: 30px; border: 2px solid #111; border-top-color: #fff; border-radius: 50%; animation: s 0.6s linear infinite; }
        @keyframes s { to { transform: rotate(360deg); } }
    </style>
</head>
<body>

    <div id="loader"><div class="spin"></div></div>

    <header>
        <a href="manage.php?repo=<?php echo $repo; ?>&path=<?php echo urlencode(dirname($file) === '.' ? '' : dirname($file)); ?>" class="back"><i class="fas fa-arrow-left"></i></a>
        <div style="font-size: 0.8rem; font-weight: 700;"><?php echo basename($file); ?></div>
        <button class="save-btn" id="saveBtn" onclick="saveFile()">SAVE</button>
    </header>

    <div class="editor-container">
        <textarea id="codeEditor" spellcheck="false"><?php echo htmlspecialchars($content); ?></textarea>
    </div>

    <div class="toolbar">
        <button class="tool-btn" onclick="ins('\t')">TAB</button>
        <button class="tool-btn" onclick="ins('{}')">{ }</button>
        <button class="tool-btn" onclick="ins('()')">( )</button>
        <button class="tool-btn" onclick="ins('\"\"')">" "</button>
        <button class="tool-btn" onclick="ins('<?php echo "<?php "; ?>')">PHP</button>
    </div>

    <script>
        // JS block ekdum alag hai PHP se
        const editor = document.getElementById('codeEditor');
        const saveBtn = document.getElementById('saveBtn');

        function ins(str) {
            const start = editor.selectionStart;
            const end = editor.selectionEnd;
            editor.value = editor.value.substring(0, start) + str + editor.value.substring(end);
            editor.selectionStart = editor.selectionEnd = start + str.length;
            editor.focus();
        }

        async function saveFile() {
            const code = editor.value;
            saveBtn.disabled = true;
            document.getElementById('loader').style.display = 'flex';

            const formData = new FormData();
            formData.append('repo', '<?php echo $repo; ?>');
            formData.append('file', '<?php echo $file; ?>');
            formData.append('sha', '<?php echo $sha; ?>');
            // Base64 encoding for safe transfer
            formData.append('content', btoa(unescape(encodeURIComponent(code))));

            try {
                const response = await fetch('save_engine.php', {
                    method: 'POST',
                    body: formData
                });
                const res = await response.json();
                if(res.status === 'success') {
                    alert('SAVED SUCCESSFULLY');
                    location.reload();
                } else {
                    alert('Error: ' + res.message);
                }
            } catch (e) {
                alert('Connection Error');
            } finally {
                saveBtn.disabled = false;
                document.getElementById('loader').style.display = 'none';
            }
        }
    </script>
</body>
</html>
