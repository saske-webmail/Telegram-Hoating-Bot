<?php
/**
 * GitFlow Pro - Integrated Authentication System
 * Developed by: Sasuke / Shivansh
 * Version: 3.1.0 (Stable)
 */

session_start();

// Agar user pehle se logged in hai toh dashboard par bhej do
if (isset($_SESSION['token']) && isset($_SESSION['user'])) {
    header('Location: dashboard.php');
    exit;
}

$error_msg = '';
$status_type = '';

// Authentication Logic
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['gh_token'])) {
    $token = trim($_POST['gh_token']);

    if (empty($token)) {
        $error_msg = "Engine requires a valid Access Token.";
        $status_type = "warning";
    } else {
        // GitHub API verification
        $ch = curl_init('https://api.github.com/user');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $token,
            'User-Agent: GitFlow-Core-V3'
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error_curl = curl_error($ch);
        curl_close($ch);

        if ($http_code === 200) {
            $user_data = json_decode($response, true);
            
            // Session initialization
            $_SESSION['token'] = $token;
            $_SESSION['user'] = [
                'login' => $user_data['login'],
                'name' => $user_data['name'] ?? $user_data['login'],
                'avatar_url' => $user_data['avatar_url'],
                'id' => $user_data['id'],
                'login_at' => time()
            ];

            // Redirect to dashboard with success
            header('Location: dashboard.php?auth=success');
            exit;
        } elseif ($http_code === 401) {
            $error_msg = "Bad Credentials. Token might be expired.";
            $status_type = "error";
        } else {
            $error_msg = "Connection Refused. API unreachable.";
            $status_type = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>GitFlow | Security Portal</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;600;900&family=Inter:wght@400;700&family=JetBrains+Mono&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #ffffff;
            --bg-dark: #000000;
            --card-glass: rgba(10, 10, 10, 0.8);
            --border-glow: rgba(255, 255, 255, 0.15);
            --error: #ff3b30;
            --warning: #ffcc00;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; outline: none; }
        
        body, html {
            height: 100%;
            background-color: var(--bg-dark);
            color: var(--primary);
            font-family: 'Inter', sans-serif;
            overflow: hidden;
        }

        /* --- BACKGROUND PARTICLES --- */
        #particles-js {
            position: absolute; width: 100%; height: 100%;
            z-index: 1;
        }

        /* --- MAIN LOGIN CONTAINER --- */
        .portal-wrapper {
            position: relative;
            z-index: 10;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .auth-card {
            background: var(--card-glass);
            width: 100%;
            max-width: 420px;
            padding: 45px 35px;
            border-radius: 35px;
            border: 1px solid var(--border-glow);
            backdrop-filter: blur(25px);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            text-align: center;
            animation: cardEntrance 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
        }

        @keyframes cardEntrance {
            from { opacity: 0; transform: translateY(40px) scale(0.95); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* Logo Branding */
        .brand-logo {
            width: 85px;
            height: 85px;
            background: #111;
            margin: 0 auto 25px;
            border-radius: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid var(--border-glow);
            position: relative;
            overflow: hidden;
        }

        .brand-logo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0.9;
        }

        .brand-logo::after {
            content: '';
            position: absolute;
            inset: 0;
            box-shadow: inset 0 0 20px rgba(255,255,255,0.05);
        }

        h1 {
            font-family: 'Outfit', sans-serif;
            font-weight: 900;
            font-size: 2rem;
            letter-spacing: -1px;
            margin-bottom: 8px;
        }

        .subtitle {
            font-size: 0.85rem;
            color: #666;
            margin-bottom: 35px;
            line-height: 1.5;
        }

        /* --- FORM STYLING --- */
        .input-group {
            position: relative;
            margin-bottom: 15px;
            text-align: left;
        }

        .input-group label {
            display: block;
            font-size: 0.7rem;
            font-weight: 700;
            color: #444;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-left: 5px;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: #555;
            font-size: 1rem;
            transition: 0.3s;
        }

        .gh-input {
            width: 100%;
            background: rgba(255,255,255,0.03);
            border: 1px solid var(--border-glow);
            padding: 18px 20px 18px 55px;
            border-radius: 18px;
            color: #fff;
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.9rem;
            transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
        }

        .gh-input:focus {
            background: rgba(255,255,255,0.07);
            border-color: #fff;
            box-shadow: 0 0 25px rgba(255,255,255,0.05);
        }

        .gh-input:focus + i {
            color: #fff;
        }

        /* --- BUTTON LOGIC --- */
        .action-container {
            margin-top: 30px;
        }

        .btn-initialize {
            width: 100%;
            background: #fff;
            color: #000;
            border: none;
            padding: 18px;
            border-radius: 18px;
            font-family: 'Outfit', sans-serif;
            font-weight: 800;
            font-size: 1rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            transition: all 0.4s;
            box-shadow: 0 10px 30px rgba(255,255,255,0.1);
        }

        .btn-initialize:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(255,255,255,0.2);
        }

        .btn-initialize:active {
            transform: translateY(1px);
        }

        /* --- NOTIFICATION CENTER --- */
        .status-box {
            background: rgba(255, 59, 48, 0.1);
            border: 1px solid rgba(255, 59, 48, 0.2);
            color: var(--error);
            padding: 15px;
            border-radius: 15px;
            margin-bottom: 25px;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: shake 0.5s cubic-bezier(.36,.07,.19,.97) both;
        }

        @keyframes shake {
            10%, 90% { transform: translate3d(-1px, 0, 0); }
            20%, 80% { transform: translate3d(2px, 0, 0); }
            30%, 50%, 70% { transform: translate3d(-4px, 0, 0); }
            40%, 60% { transform: translate3d(4px, 0, 0); }
        }

        /* --- LOADER OVERLAY --- */
        #engineLoader {
            position: fixed; inset: 0; background: #000; z-index: 1000;
            display: none; align-items: center; justify-content: center;
            flex-direction: column;
        }

        .loader-ring {
            width: 60px; height: 60px; border: 4px solid #111;
            border-top: 4px solid #fff; border-radius: 50%;
            animation: rotate 1s linear infinite;
        }

        @keyframes rotate { to { transform: rotate(360deg); } }

        .loader-text {
            margin-top: 20px;
            font-family: 'Outfit';
            letter-spacing: 5px;
            font-size: 0.6rem;
            color: #444;
            font-weight: 900;
        }

        /* --- FOOTER --- */
        .footer-info {
            margin-top: 40px;
            font-size: 0.65rem;
            color: #333;
            letter-spacing: 2px;
            font-weight: 700;
            text-transform: uppercase;
        }

        /* Responsive Mobile Fixes */
        @media (max-width: 480px) {
            .auth-card { padding: 35px 25px; border-radius: 30px; }
            h1 { font-size: 1.7rem; }
        }
    </style>
</head>
<body>

    <div id="particles-js"></div>

    <div id="engineLoader">
        <div class="loader-ring"></div>
        <div class="loader-text" id="loadStatus">AUTHENTICATING ENGINE...</div>
    </div>

    <div class="portal-wrapper">
        <div class="auth-card">
            
            <div class="brand-logo">
                <img src="https://i.ibb.co/qFghH6M7/file-1733.jpg" alt="GitFlow Logo">
            </div>

            <h1>GITFLOW V3</h1>
            <p class="subtitle">Securely manage your repositories with Sasuke's automated code engine.</p>

            <?php if($error_msg): ?>
                <div class="status-box">
                    <i class="fas fa-shield-alt"></i>
                    <span><?php echo $error_msg; ?></span>
                </div>
            <?php endif; ?>

            <form action="" method="POST" id="authForm" onsubmit="return startEngine()">
                <div class="input-group">
                    <label>Personal Access Token</label>
                    <div class="input-wrapper">
                        <i class="fas fa-fingerprint"></i>
                        <input type="password" name="gh_token" class="gh-input" placeholder="ghp_************************" required>
                    </div>
                </div>

                <div class="action-container">
                    <button type="submit" class="btn-initialize">
                        <i class="fas fa-power-off"></i> INITIALIZE SYSTEM
                    </button>
                </div>
            </form>

            <div class="footer-info">
                Sasuke Terminal Core • Encryption Active
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <script>
        // PARTICLES CONFIG
        particlesJS("particles-js", {
            "particles": {
                "number": { "value": 80, "density": { "enable": true, "value_area": 800 } },
                "color": { "value": "#ffffff" },
                "shape": { "type": "circle" },
                "opacity": { "value": 0.2, "random": false },
                "size": { "value": 2, "random": true },
                "line_linked": { "enable": true, "distance": 150, "color": "#ffffff", "opacity": 0.1, "width": 1 },
                "move": { "enable": true, "speed": 1, "direction": "none", "random": false, "straight": false, "out_mode": "out", "bounce": false }
            },
            "interactivity": {
                "events": { "onhover": { "enable": true, "mode": "grab" }, "onclick": { "enable": true, "mode": "push" } }
            },
            "retina_detect": true
        });

        // FORM HANDLING
        function startEngine() {
            const overlay = document.getElementById('engineLoader');
            const status = document.getElementById('loadStatus');
            
            overlay.style.display = 'flex';
            
            // Sequential loading text effect
            const texts = ["CONTACTING GITHUB...", "VERIFYING CREDENTIALS...", "BOOTING SASUKE ENGINE..."];
            let i = 0;
            const interval = setInterval(() => {
                if(i < texts.length) {
                    status.innerText = texts[i];
                    i++;
                } else {
                    clearInterval(interval);
                }
            }, 500);

            return true;
        }
    </script>
</body>
</html>