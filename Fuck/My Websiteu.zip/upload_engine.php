<?php
/**
 * GitFlow Industrial Upload Engine v16.0
 * FIX: ERR_EMPTY_RESPONSE / TIMEOUT
 */
session_start();

// --- 1. INDUSTRIAL STABILITY SETTINGS ---
set_time_limit(0); 
ini_set('memory_limit', '256M'); 
ignore_user_abort(true);

// Browser ko turant batao ki hum zinda hain
ob_start();
echo "Processing..."; 
ob_end_flush();
flush();

if (!isset($_SESSION['token']) || !isset($_POST['repo'])) {
    die("Access Denied");
}

$token = $_SESSION['token'];
$user  = $_SESSION['user']['login'];
$repo  = $_POST['repo'];
$path  = isset($_POST['path']) ? $_POST['path'] : '';
$files = $_FILES['files'] ?? null;

/**
 * PUSH ENGINE (Optimized)
 */
function uploadToGit($fPath, $content, $tk, $us, $rp) {
    $url = "https://api.github.com/repos/$us/$rp/contents/" . str_replace(' ', '%20', $fPath);
    
    // Check SHA
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer $tk", "User-Agent: GitFlow-Industrial"]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $check = json_decode(curl_exec($ch), true);
    $sha = $check['sha'] ?? null;
    curl_close($ch);

    $data = [
        "message" => "Upload: " . basename($fPath),
        "content" => base64_encode($content)
    ];
    if ($sha) $data["sha"] = $sha;

    // PUT Request
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $tk",
        "User-Agent: GitFlow-Industrial",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return ($code >= 200 && $code < 300);
}

// --- 2. EXECUTION ---
if ($files && is_array($files['name'])) {
    foreach ($files['tmp_name'] as $i => $tmp) {
        if ($files['error'][$i] === UPLOAD_ERR_OK) {
            $fName = $files['name'][$i];
            $full = ($path ? rtrim($path, '/') . '/' : '') . $fName;
            $data = file_get_contents($tmp);
            
            // Push & Wait
            uploadToGit($full, $data, $token, $user, $repo);
            
            // HopWeb Cooling Period
            usleep(200000); // 0.2s gap
        }
    }
}

// --- 3. CLEAN EXIT ---
$final = "manage.php?repo=$repo&path=" . urlencode($path);
echo "<script>window.location.href='$final';</script>";
exit;
