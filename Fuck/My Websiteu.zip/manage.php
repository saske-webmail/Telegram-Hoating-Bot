<?php
session_start();
error_reporting(0);

if (!isset($_SESSION['token']) || !isset($_GET['repo'])) {
    header('Location: index.php');
    exit;
}

$token = $_SESSION['token'];
$user  = $_SESSION['user']['login'];
$repo  = $_GET['repo'];
$path  = isset($_GET['path']) ? $_GET['path'] : '';

// Fetch Data
$api_url = "https://api.github.com/repos/$user/$repo/contents/" . str_replace(' ', '%20', $path);
$ch = curl_init($api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer '.$token, 'User-Agent: GitFlow-Industrial']);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$res = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$files = ($status === 200) ? json_decode($res, true) : [];
if(is_array($files)) {
    usort($files, function($a, $b) {
        return ($b['type'] === 'dir') <=> ($a['type'] === 'dir');
    });
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $repo; ?> / GitFlow</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        :root {
            --bg: #000000;
            --surface: #0a0a0a;
            --border: #1a1a1a;
            --text: #ffffff;
            --dim: #71717a;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        body { background: var(--bg); color: var(--text); font-family: 'Inter', sans-serif; }

        /* Loader */
        #load { position: fixed; inset: 0; background: rgba(0,0,0,0.4); backdrop-filter: blur(10px); display: none; align-items: center; justify-content: center; z-index: 9999; }
        .spin { width: 30px; height: 30px; border: 2px solid rgba(255,255,255,0.1); border-top-color: #fff; border-radius: 50%; animation: s 0.6s linear infinite; }
        @keyframes s { to { transform: rotate(360deg); } }

        /* Header */
        header { height: 60px; border-bottom: 1.5px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 16px; position: sticky; top: 0; background: #000; z-index: 100; }
        .back { color: var(--dim); font-size: 1.1rem; text-decoration: none; width: 40px; }
        .repo-name { font-family: 'JetBrains Mono'; font-size: 0.9rem; font-weight: 700; flex: 1; text-align: center; }

        .container { padding: 16px; max-width: 650px; margin: 0 auto; padding-bottom: 100px; }

        /* Terminal Path Bar - Better & Easy */
        .path-strip { background: var(--surface); border: 1.5px solid var(--border); border-radius: 8px; padding: 12px; margin-bottom: 20px; display: flex; align-items: center; gap: 8px; overflow-x: auto; white-space: nowrap; scrollbar-width: none; }
        .path-strip i { color: var(--dim); font-size: 0.8rem; }
        .path-strip a { color: var(--dim); text-decoration: none; font-family: 'JetBrains Mono'; font-size: 0.75rem; font-weight: 600; }
        .path-strip b { color: #fff; font-family: 'JetBrains Mono'; font-size: 0.75rem; }

        /* Explorer */
        .explorer { background: var(--surface); border: 1.5px solid var(--border); border-radius: 12px; overflow: hidden; }
        .row { display: flex; align-items: center; padding: 14px 16px; border-bottom: 1px solid var(--border); color: inherit; text-decoration: none; }
        .row:last-child { border-bottom: none; }
        .row:active { background: #111; }
        
        .r-icon { width: 35px; font-size: 1.1rem; color: var(--dim); }
        .r-body { flex: 1; min-width: 0; }
        .r-title { display: block; font-size: 0.85rem; font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .r-meta { font-size: 0.65rem; color: #444; font-family: 'JetBrains Mono'; margin-top: 2px; text-transform: uppercase; }

        .r-actions { display: flex; gap: 15px; align-items: center; }
        .r-btn { color: #333; font-size: 0.95rem; }
        .r-btn:active { color: #fff; }

        /* Industrial FAB */
        .fab { position: fixed; bottom: 24px; right: 20px; z-index: 1000; }
        .fab-main { width: 56px; height: 56px; background: #fff; color: #000; border-radius: 16px; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; box-shadow: 0 10px 30px #000; transition: 0.3s; }
        .fab-menu { position: absolute; bottom: 70px; right: 0; display: none; flex-direction: column; gap: 8px; width: 180px; }
        .fab-item { background: #111; border: 1.5px solid var(--border); color: #fff; padding: 14px; border-radius: 12px; font-size: 0.8rem; font-weight: 600; display: flex; align-items: center; gap: 10px; }
        .fab-item:active { background: #fff; color: #000; }

        /* Modal */
        .modal { position: fixed; inset: 0; background: rgba(0,0,0,0.9); backdrop-filter: blur(10px); display: none; align-items: center; justify-content: center; z-index: 2000; padding: 20px; }
        .m-card { background: #000; border: 1.5px solid var(--border); width: 100%; max-width: 320px; padding: 24px; border-radius: 16px; }
        .m-input { width: 100%; background: #0a0a0a; border: 1.5px solid var(--border); padding: 14px; border-radius: 8px; color: #fff; font-size: 0.9rem; margin-bottom: 20px; font-family: 'JetBrains Mono'; outline: none; }
        .m-btns { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .m-btn { padding: 12px; border-radius: 8px; border: none; font-weight: 700; font-size: 0.8rem; cursor: pointer; }
        .m-sec { background: #111; color: #fff; }
        .m-pri { background: #fff; color: #000; }

        #toast { position: fixed; top: 15px; left: 50%; transform: translateX(-50%); background: #fff; color: #000; padding: 8px 16px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; display: none; z-index: 10000; }
    </style>
</head>
<body>

<div id="load"><div class="spin"></div></div>
<div id="toast">ACTION SUCCESSFUL</div>

<header>
    <a href="javascript:void(0)" onclick="goBack()" class="back"><i class="fas fa-arrow-left"></i></a>
    <div class="repo-name"><?php echo strtoupper($repo); ?></div>
    <div style="width:40px; text-align:right;" onclick="copyL('<?php echo "https://github.com/$user/$repo"; ?>')"><i class="fas fa-link" style="font-size:0.9rem; color:var(--dim);"></i></div>
</header>

<div class="container">
    <div class="path-strip">
        <i class="fas fa-terminal"></i>
        <a href="manage.php?repo=<?php echo $repo; ?>">root</a>
        <?php 
        if($path) {
            $acc = ''; $pts = explode('/', $path);
            foreach($pts as $p) {
                $acc .= ($acc ? '/' : '') . $p;
                echo '<i>/</i>';
                echo '<a href="manage.php?repo='.$repo.'&path='.urlencode($acc).'">'.$p.'</a>';
            }
        }
        ?>
    </div>

    <div class="explorer">
        <?php if(empty($files)): ?>
            <div style="padding:60px; text-align:center; font-size:0.6rem; color:#222; font-weight:900; letter-spacing:4px;">NO_DATA_SYNC</div>
        <?php endif; ?>

        <?php foreach($files as $f): 
            $isD = ($f['type'] === 'dir');
            $target = $isD ? "manage.php?repo=$repo&path=".urlencode($f['path']) : "editor.php?repo=$repo&file=".urlencode($f['path']);
        ?>
        <div class="row">
            <div class="r-icon" onclick="nav('<?php echo $target; ?>')">
                <i class="fas <?php echo $isD ? 'fa-folder' : 'fa-file-code'; ?>"></i>
            </div>
            <div class="r-body" onclick="nav('<?php echo $target; ?>')">
                <span class="r-title"><?php echo $f['name']; ?></span>
                <span class="r-meta"><?php echo $isD ? 'DIR' : round($f['size']/1024, 1).' KB'; ?></span>
            </div>
            <div class="r-actions">
                <a href="<?php echo $f['download_url']; ?>" download class="r-btn"><i class="fas fa-download"></i></a>
                <i class="fas fa-trash-alt r-btn" onclick="del('<?php echo $f['path']; ?>', '<?php echo $f['sha']; ?>', '<?php echo $f['type']; ?>')"></i>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="fab">
    <div class="fab-menu" id="fMenu">
        <div class="fab-item" onclick="openM('file')"><i class="fas fa-plus"></i> NEW FILE</div>
        <div class="fab-item" onclick="openM('folder')"><i class="fas fa-folder-plus"></i> NEW FOLDER</div>
        <div class="fab-item" onclick="document.getElementById('uInp').click()"><i class="fas fa-upload"></i> UPLOAD</div>
    </div>
    <div class="fab-main" onclick="toggleF()"><i class="fas fa-bars-staggered"></i></div>
</div>

<form id="uForm" action="upload_engine.php" method="POST" enctype="multipart/form-data" style="display:none;">
    <input type="hidden" name="repo" value="<?php echo $repo; ?>">
    <input type="hidden" name="path" value="<?php echo $path; ?>">
    <input type="file" name="files[]" id="uInp" multiple onchange="doUp()">
</form>

<div class="modal" id="modal">
    <div class="m-card">
        <h3 id="mT" style="font-size:0.9rem; margin-bottom:10px;">Create</h3>
        <input type="text" id="mI" class="m-input" placeholder="Name...">
        <div class="m-btns">
            <button class="m-btn m-sec" onclick="closeM()">CANCEL</button>
            <button class="m-btn m-pri" onclick="doCreate()">CREATE</button>
        </div>
    </div>
</div>

<script>
    let mode = '';
    function nav(u) { document.getElementById('load').style.display='flex'; window.location.href=u; }
    function toggleF() { let m = document.getElementById('fMenu'); m.style.display = (m.style.display==='flex') ? 'none' : 'flex'; }
    function openM(t) { mode=t; document.getElementById('mT').innerText="NEW "+t.toUpperCase(); document.getElementById('modal').style.display='flex'; toggleF(); }
    function closeM() { document.getElementById('modal').style.display='none'; }
    function copyL(u) { navigator.clipboard.writeText(u); let t=document.getElementById('toast'); t.style.display='block'; setTimeout(()=>t.style.display='none', 2000); }
    function doUp() { document.getElementById('load').style.display='flex'; document.getElementById('uForm').submit(); }
    function doCreate() { let n=document.getElementById('mI').value; if(!n) return; nav(`create_item_engine.php?repo=<?php echo $repo; ?>&path=<?php echo urlencode($path); ?>&name=${n}&type=${mode}`); }
    function del(p, s, t) { if(confirm("Confirm deletion?")) { nav(`delete_file_engine.php?repo=<?php echo $repo; ?>&path=${p}&sha=${s}&type=${t}`); } }
    function goBack() { let p="<?php echo $path; ?>"; if(!p) nav('dashboard.php'); else { let pts=p.split('/'); pts.pop(); nav("manage.php?repo=<?php echo $repo; ?>&path="+encodeURIComponent(pts.join('/'))); } }
</script>
</body>
</html>