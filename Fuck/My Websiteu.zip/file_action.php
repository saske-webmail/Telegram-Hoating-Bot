<?php
session_start();
if (!isset($_SESSION['token'])) exit("Unauthorized");

$token = $_SESSION['token'];
$user = $_SESSION['user']['login'];
$repo = $_GET['repo'];
$action = $_GET['action'];

if ($action == 'create') {
    $name = $_GET['name'];
    $path = $_GET['path'] ? $_GET['path'].'/'.$name : $name;
    $url = "https://api.github.com/repos/$user/$repo/contents/$path";
    
    $data = [
        "message" => "Create $name via GitFlow",
        "content" => base64_encode("<?php\n// New file created via GitFlow\n?>")
    ];
} 

elseif ($action == 'delete') {
    $path = $_GET['path'];
    $sha = $_GET['sha'];
    $url = "https://api.github.com/repos/$user/$repo/contents/$path";
    
    $data = [
        "message" => "Delete file via GitFlow",
        "sha" => $sha
    ];
}

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, ($action == 'create' ? "PUT" : "DELETE"));
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer '.$token, 'User-Agent: GitFlow-Pro', 'Content-Type: application/json']);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
curl_close($ch);

header("Location: manage.php?repo=$repo&path=".dirname($path));
exit;
