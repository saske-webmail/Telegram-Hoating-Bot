<?php
session_start();
if (!isset($_SESSION['token'])) { header('Location: index.php'); exit; }
$user = $_SESSION['user'] ?? [];
$avatar = $user['avatar_url'] ?? 'https://i.ibb.co/qFghH6M7/file-1733.jpg';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>GitFlow | Create & Deploy</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@600;800&family=JetBrains+Mono&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        :root {
            --bg: #000000;
            --card: #0a0a0a;
            --border: rgba(255, 255, 255, 0.12);
            --accent: #ffffff;
            --text-main: #ffffff;
            --text-muted: #888888;
            --success: #32d74b;
            --error: #ff453a;
            --zip-color: #f1c40f;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; outline: none; }
        body { background: var(--bg); color: var(--text-main); font-family: 'Inter', sans-serif; line-height: 1.6; }

        /* Navbar */
        .navbar { height: 65px; display: flex; align-items: center; justify-content: space-between; padding: 0 20px; border-bottom: 1px solid var(--border); background: rgba(0,0,0,0.8); backdrop-filter: blur(25px); position: sticky; top: 0; z-index: 1000; }
        .logo-box { display: flex; align-items: center; gap: 12px; text-decoration: none; color: white; }
        .logo-box img { width: 30px; border-radius: 8px; }
        .back-link { color: var(--text-muted); text-decoration: none; font-size: 0.9rem; font-weight: 600; }

        .container { padding: 25px 20px; max-width: 500px; margin: 0 auto; position: relative; }

        /* Page Intro */
        .intro { margin-bottom: 30px; }
        .intro h1 { font-family: 'Outfit'; font-size: 1.6rem; font-weight: 800; }
        .intro p { font-size: 0.85rem; color: var(--text-muted); }

        /* Form Controls */
        .form-group { margin-bottom: 24px; }
        .label-text { display: block; font-size: 0.7rem; font-weight: 800; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 10px; }
        
        .input-field { width: 100%; background: var(--card); border: 1px solid var(--border); padding: 16px; border-radius: 14px; color: #fff; font-size: 1rem; transition: 0.3s; }
        .input-field:focus { border-color: #fff; box-shadow: 0 0 15px rgba(255,255,255,0.05); }

        /* Premium Toggle Switch */
        .toggle-row { display: flex; align-items: center; justify-content: space-between; background: var(--card); padding: 18px; border-radius: 16px; border: 1px solid var(--border); cursor: pointer; transition: 0.2s; }
        .toggle-row:active { transform: scale(0.98); }
        .toggle-info h4 { font-size: 0.95rem; font-weight: 600; }
        .toggle-info p { font-size: 0.75rem; color: var(--text-muted); }

        .switch { position: relative; width: 48px; height: 26px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; inset: 0; background: #222; border-radius: 30px; transition: 0.4s; }
        .slider:before { position: absolute; content: ""; height: 20px; width: 20px; left: 3px; bottom: 3px; background: white; border-radius: 50%; transition: 0.4s; }
        input:checked + .slider { background: var(--success); }
        input:checked + .slider:before { transform: translateX(22px); }

        /* Asset Engine (File System UI) */
        .asset-engine { background: var(--card); border: 1px solid var(--border); border-radius: 18px; padding: 15px; margin-top: 10px; }
        .engine-tabs { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; margin-bottom: 15px; }
        
        .tab-btn { background: rgba(255,255,255,0.04); border: 1px solid var(--border); color: #fff; padding: 12px 5px; border-radius: 12px; font-size: 0.7rem; font-weight: 700; text-align: center; cursor: pointer; }
        .tab-btn i { display: block; margin-bottom: 6px; font-size: 1.1rem; color: var(--text-muted); }
        .tab-btn:active { background: var(--border); }

        /* Dynamic File List */
        .preview-pane { background: #000; border: 1px solid var(--border); border-radius: 12px; min-height: 150px; max-height: 300px; overflow-y: auto; position: relative; }
        .file-entry { padding: 12px 15px; border-bottom: 1px solid #111; display: flex; align-items: center; justify-content: space-between; font-family: 'JetBrains Mono'; font-size: 0.75rem; animation: slideIn 0.3s ease-out; }
        .file-entry span { color: #eee; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 80%; }
        .file-entry i { font-size: 0.9rem; }
        
        .empty-state { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; width: 100%; }
        .empty-state i { font-size: 2rem; color: #1a1a1a; margin-bottom: 10px; }
        .empty-state p { font-size: 0.75rem; color: #333; font-weight: 600; }

        /* Submit Area */
        .deploy-btn { width: 100%; background: #fff; color: #000; border: none; padding: 18px; border-radius: 16px; font-family: 'Outfit'; font-weight: 900; font-size: 1rem; margin-top: 35px; cursor: pointer; box-shadow: 0 15px 30px rgba(255,255,255,0.1); transition: 0.3s; }
        .deploy-btn:disabled { opacity: 0.5; cursor: not-allowed; }

        /* Toast Message */
        #toast { position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%); background: #fff; color: #000; padding: 12px 25px; border-radius: 50px; font-weight: 800; font-size: 0.85rem; display: none; z-index: 5000; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }

        @keyframes slideIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="dashboard.php" class="back-link"><i class="fas fa-chevron-left"></i></a>
        <div style="font-family:'Outfit'; font-weight:800; letter-spacing:1px; font-size:1.1rem;">GITFLOW</div>
        <img src="<?php echo $avatar; ?>" style="width:30px; height:30px; border-radius:50%; border:1px solid var(--border);">
    </nav>

    <div class="container">
        <div class="intro">
            <h1>Create Project</h1>
            <p>Deploy your assets to a fresh GitHub repository.</p>
        </div>

        <form action="create_engine.php" method="POST" enctype="multipart/form-data" id="deployForm">
            
            <div class="form-group">
                <label class="label-text">Repo Identifier</label>
                <input type="text" name="repo_name" class="input-field" placeholder="e.g. my-web-app" required autocomplete="off">
            </div>

            <label class="toggle-row">
                <div class="toggle-info">
                    <h4>Private Repository</h4>
                    <p>Restrict access to only your account.</p>
                </div>
                <div class="switch">
                    <input type="checkbox" name="is_private" id="privateCheck">
                    <span class="slider"></span>
                </div>
            </label>

            <div class="form-group" style="margin-top: 30px;">
                <label class="label-text">Structure & Deployment</label>
                <div class="asset-engine">
                    <div class="engine-tabs">
                        <div class="tab-btn" onclick="triggerInput('fileInp')">
                            <i class="fas fa-file-code"></i>+ Files
                        </div>
                        <div class="tab-btn" onclick="triggerInput('folderInp')">
                            <i class="fas fa-folder-open"></i>+ Folder
                        </div>
                        <div class="tab-btn" onclick="triggerInput('zipInp')">
                            <i class="fas fa-file-archive" style="color:var(--zip-color);"></i>+ ZIP
                        </div>
                    </div>

                    <input type="file" id="fileInp" multiple style="display:none;" onchange="processFiles(this, 'file')">
                    <input type="file" id="folderInp" webkitdirectory style="display:none;" onchange="processFiles(this, 'folder')">
                    <input type="file" id="zipInp" name="zip_file" accept=".zip" style="display:none;" onchange="processFiles(this, 'zip')">
                    
                    <div id="fileContainer" style="display:none;"></div>

                    <div class="preview-pane" id="previewPane">
                        <div class="empty-state" id="emptyState">
                            <i class="fas fa-layer-group"></i>
                            <p>WAITING FOR ASSETS</p>
                        </div>
                    </div>
                </div>
            </div>

            <button type="submit" class="deploy-btn" id="submitBtn">INITIALIZE DEPLOYMENT</button>
        </form>
    </div>

    <div id="toast"></div>

    <script>
        let fileCounter = 0;

        function triggerInput(id) { document.getElementById(id).click(); }

        function showToast(msg) {
            const t = document.getElementById('toast');
            t.innerText = msg;
            t.style.display = 'block';
            setTimeout(() => t.style.display = 'none', 3000);
        }

        function processFiles(input, type) {
            const pane = document.getElementById('previewPane');
            const container = document.getElementById('fileContainer');
            const empty = document.getElementById('emptyState');
            
            if (empty) empty.style.display = "none";
            if (type === 'zip') showToast("ZIP Archive Added");

            const files = input.files;
            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                const path = file.webkitRelativePath || file.name;
                
                // 1. UI Preview
                const entry = document.createElement('div');
                entry.className = 'file-entry';
                let icon = type === 'zip' ? 'fa-file-archive' : 'fa-file';
                let color = type === 'zip' ? 'var(--zip-color)' : 'var(--success)';
                
                entry.innerHTML = `
                    <span><i class="fas ${icon}" style="color:${color}; margin-right:10px;"></i> ${path}</span>
                    <i class="fas fa-check-circle" style="color:var(--success)"></i>
                `;
                pane.appendChild(entry);

                // 2. Clone File to Main Form (Crucial for Multi-select)
                if (type !== 'zip') {
                    const dataTransfer = new DataTransfer();
                    dataTransfer.items.add(file);
                    
                    const newInp = document.createElement('input');
                    newInp.type = 'file';
                    newInp.name = 'user_files[]';
                    newInp.files = dataTransfer.files;
                    container.appendChild(newInp);

                    // 3. Add Path Hidden Input
                    const pathInp = document.createElement('input');
                    pathInp.type = 'hidden';
                    pathInp.name = 'paths[]';
                    pathInp.value = path;
                    container.appendChild(pathInp);
                }
            }
            // Auto scroll to bottom
            pane.scrollTop = pane.scrollHeight;
        }

        document.getElementById('deployForm').onsubmit = function() {
            const btn = document.getElementById('submitBtn');
            btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> UPLOADING ASSETS...';
            btn.disabled = true;
        };

        // Handle URL status messages
        window.onload = () => {
            const params = new URLSearchParams(window.location.search);
            if (params.get('status') === 'error') showToast("❌ " + params.get('msg'));
        };
    </script>
</body>
</html>