<?php
session_start();
$token = $_SESSION['token'];
$user  = $_SESSION['user']['login'];
$repo  = $_GET['repo'];
$path  = $_GET['path'];
$name  = $_GET['name'];
$type  = $_GET['type'];

$fullPath = ($path ? $path . '/' : '') . $name;

if ($type === 'folder') {
    $fullPath .= '/.gitkeep'; // Folder trick
    $content = "Directory created by GitFlow";
} else {
    $content = " "; // Empty file
}

$url = "https://api.github.com/repos/$user/$repo/contents/$fullPath";
$data = json_encode([
    "message" => "Created $type: $name",
    "content" => base64_encode($content)
]);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer $token", "User-Agent: GitFlow"]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
curl_close($ch);

header("Location: manage.php?repo=$repo&path=$path");
?>
