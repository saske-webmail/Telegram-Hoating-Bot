if ($action == 'login_check') {
    $res = github_api("user", $token); // GitHub se user data mangwao
    if (isset($res['login'])) {
        // Agar login successful hai toh user info return karo
        echo json_encode([
            "status" => "success", 
            "username" => $res['login'], 
            "avatar" => $res['avatar_url']
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid Token"]);
    }
    exit;
}