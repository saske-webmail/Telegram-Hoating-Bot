<?php
session_start();
// Error reporting off taaki background process na tute
error_reporting(0);

if (!isset($_SESSION['token'])) { die("Unauthorized"); }

$token = $_SESSION['token'];
$user  = $_SESSION['user']['login'];
$repo  = $_POST['repo'];
$path  = $_POST['path']; // Kis folder ke andar extract karna hai

if (isset($_FILES['zip_file']) && $_FILES['zip_file']['error'] == 0) {
    $zipPath = $_FILES['zip_file']['tmp_name'];
    $zip = new ZipArchive;

    if ($zip->open($zipPath) === TRUE) {
        // ZIP ke andar kitni files hain
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $fileName = $zip->getNameIndex($i);
            
            // Agar folder hai toh skip karo (GitHub automatic handle karta hai)
            if (substr($fileName, -1) == '/') continue;

            $content = $zip->getFromIndex($i);
            // Full path create karo (Current Path + Zip Internal Path)
            $githubPath = ($path ? $path . '/' : '') . $fileName;

            // --- GITHUB PUT API ---
            $url = "https://api.github.com/repos/$user/$repo/contents/" . $githubPath;
            
            // SHA Check (Overwrite Protection)
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer $token", "User-Agent: GitFlow"]);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $res = json_decode(curl_exec($ch), true);
            $sha = isset($res['sha']) ? $res['sha'] : null;
            curl_close($ch);

            $data = ["message" => "Extracted: $fileName", "content" => base64_encode($content)];
            if ($sha) $data["sha"] = $sha;

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer $token", "User-Agent: GitFlow"]);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_exec($ch);
            curl_close($ch);
        }
        $zip->close();
        
        // Success! Wapas manage page par bhej do
        header("Location: manage.php?repo=$repo&path=$path&msg=ZipExtracted");
    } else {
        echo "Failed to open ZIP.";
    }
} else {
    echo "No file uploaded or Error in upload.";
}
?>
