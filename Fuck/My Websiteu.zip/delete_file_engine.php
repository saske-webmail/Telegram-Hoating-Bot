<?php
/**
 * GitFlow Stable Delete Engine v12.0
 * Fix for ERR_EMPTY_RESPONSE on HopWeb/Mobile Servers
 */
session_start();
set_time_limit(0); 
ignore_user_abort(true);

if (!isset($_SESSION['token'])) { die("Auth Failed"); }

$token = $_SESSION['token'];
$user  = $_SESSION['user']['login'];
$repo  = $_GET['repo'];
$path  = $_GET['path'];
$sha   = $_GET['sha'] ?? null;
$type  = $_GET['type'] ?? 'file';

function safeDelete($tk, $us, $rp, $pt, $sh = null) {
    // 1. Agar folder hai, toh pehle uski files ki list lo
    $url = "https://api.github.com/repos/$us/$rp/contents/" . str_replace(' ', '%20', $pt);
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer $tk", "User-Agent: GitFlow-Core"]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = json_decode(curl_exec($ch), true);
    curl_close($ch);

    if (is_array($res) && !isset($res['sha'])) {
        // It's a directory, delete all children first
        foreach ($res as $item) {
            safeDelete($tk, $us, $rp, $item['path'], $item['sha']);
        }
    } else {
        // It's a file, delete it
        $targetSha = $sh ?? ($res['sha'] ?? null);
        if (!$targetSha) return;

        $delUrl = "https://api.github.com/repos/$us/$rp/contents/" . str_replace(' ', '%20', $pt);
        $data = json_encode(["message" => "System: Cleaned $pt", "sha" => $targetSha]);

        $ch = curl_init($delUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer $tk", "User-Agent: GitFlow-Core", "Content-Type: application/json"]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_exec($ch);
        curl_close($ch);
        
        // Very important: small pause to keep HopWeb alive
        usleep(50000); 
    }
}

// Start Process
safeDelete($token, $user, $repo, $path, $sha);

// After success, go back
$parent = dirname($path);
if ($parent === '.') $parent = '';
header("Location: manage.php?repo=$repo&path=" . urlencode($parent));
exit;
