<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['token'])) {
    echo json_encode(['status' => 'error', 'message' => 'Auth Failed']);
    exit;
}

$token   = $_SESSION['token'];
$user    = $_SESSION['user']['login'];
$repo    = $_POST['repo'];
$file    = $_POST['file'];
$sha     = $_POST['sha'];
$content = $_POST['content']; // Base64 encoded from JS

$url = "https://api.github.com/repos/$user/$repo/contents/" . str_replace(' ', '%20', $file);

$data = json_encode([
    "message" => "Editor Update: " . basename($file),
    "content" => $content,
    "sha"     => $sha
]);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer $token",
    "User-Agent: GitFlow-Console",
    "Content-Type: application/json"
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode >= 200 && $httpCode < 300) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Git API Error: ' . $httpCode]);
}
