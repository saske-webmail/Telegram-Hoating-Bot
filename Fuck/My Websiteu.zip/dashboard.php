<?php
session_start();
if (!isset($_SESSION['token'])) { header('Location: index.php'); exit; }

$user = $_SESSION['user'] ?? [];
$token = $_SESSION['token'];

// Null Safe Name & Avatar
$full_name = (string)($user['name'] ?? $user['login'] ?? 'Developer');
$first_name = explode(' ', $full_name)[0];
$avatar_url = $user['avatar_url'] ?? 'https://ui-avatars.com/api/?name='.$first_name;

// Fetch Repos
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.github.com/user/repos?sort=updated&per_page=20');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer '.$token, 'User-Agent: GitFlow-Pro']);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
$repos = json_decode($response, true);
curl_close($ch);

if (!is_array($repos)) { $repos = []; }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>GitFlow | Dashboard</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@600;800&family=JetBrains+Mono&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        :root {
            --bg: #000000;
            --card: #0c0c0c;
            --border: rgba(255, 255, 255, 0.08);
            --text-main: #ffffff;
            --text-muted: #71717a;
            --error: #ff453a;
            --success: #32d74b;
            --accent: #ffffff;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        body { background: var(--bg); color: var(--text-main); font-family: 'Inter', sans-serif; line-height: 1.5; }

        /* Official Header */
        .navbar { height: 60px; display: flex; align-items: center; justify-content: space-between; padding: 0 16px; border-bottom: 1px solid var(--border); background: rgba(0,0,0,0.8); backdrop-filter: blur(20px); position: sticky; top: 0; z-index: 1000; }
        .logo { font-family: 'Outfit'; font-size: 1.1rem; font-weight: 800; display: flex; align-items: center; gap: 10px; text-decoration: none; color: white; }
        .logo img { width: 28px; border-radius: 6px; }
        
        .nav-actions { display: flex; gap: 8px; }
        .nav-icon { width: 34px; height: 34px; display: flex; align-items: center; justify-content: center; border-radius: 8px; border: 1px solid var(--border); color: var(--text-muted); font-size: 0.9rem; transition: 0.2s; }
        .nav-icon:active { background: var(--border); color: #fff; }

        .container { padding: 20px; max-width: 500px; margin: 0 auto; }

        /* User Identity */
        .user-hero { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; padding: 4px; }
        .user-pfp { width: 44px; height: 44px; border-radius: 50%; border: 1px solid var(--border); }
        .user-hero h1 { font-family: 'Outfit'; font-size: 1.25rem; font-weight: 700; }
        .user-hero p { font-size: 0.75rem; color: var(--text-muted); font-weight: 500; }

        /* Action Layer */
        .btn-create { width: 100%; background: #fff; color: #000; border: none; padding: 14px; border-radius: 10px; font-family: 'Outfit'; font-weight: 800; font-size: 0.9rem; margin-bottom: 12px; display: flex; align-items: center; justify-content: center; gap: 8px; cursor: pointer; }
        
        .search-container { position: relative; margin-bottom: 30px; }
        .search-container i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--text-muted); font-size: 0.85rem; }
        .search-input { width: 100%; background: var(--card); border: 1px solid var(--border); padding: 12px 12px 12px 38px; border-radius: 10px; color: #fff; font-size: 0.9rem; }

        /* --- OFFICIAL REPO CARD --- */
        .repo-card { background: var(--card); border: 1px solid var(--border); border-radius: 14px; margin-bottom: 16px; overflow: hidden; }
        
        .card-content { padding: 16px; display: flex; justify-content: space-between; align-items: flex-start; }
        .repo-info { flex: 1; }
        .repo-name { font-size: 1rem; font-weight: 600; margin-bottom: 4px; display: block; }
        
        .repo-stats { display: flex; flex-wrap: wrap; gap: 10px; font-family: 'JetBrains Mono'; font-size: 0.65rem; color: var(--text-muted); font-weight: 500; }
        .status-badge { padding: 2px 6px; border-radius: 4px; background: rgba(255,255,255,0.05); font-weight: 700; }
        .status-pub { color: var(--success); }
        .status-pri { color: var(--error); }

        .card-ctrl { display: flex; flex-direction: column; gap: 12px; align-items: flex-end; }
        .ctrl-icon { font-size: 1.1rem; color: var(--text-muted); cursor: pointer; }
        .ctrl-icon-del { color: rgba(255, 69, 58, 0.4); }

        /* Action Bottom Strip */
        .card-footer { background: rgba(255,255,255,0.02); border-top: 1px solid var(--border); display: grid; grid-template-columns: 1fr 1fr; }
        .footer-btn { padding: 10px; text-align: center; font-size: 0.7rem; font-weight: 700; letter-spacing: 1px; color: var(--text-muted); text-decoration: none; border-right: 1px solid var(--border); }
        .footer-btn:last-child { border-right: none; color: var(--error); opacity: 0.8; }
        .footer-btn:active { background: rgba(255,255,255,0.05); color: #fff; }

        /* --- DIALOGS & TOASTS --- */
        .modal { position: fixed; inset: 0; background: rgba(0,0,0,0.9); backdrop-filter: blur(8px); display: none; align-items: center; justify-content: center; z-index: 2000; padding: 20px; }
        .modal-content { background: #111; border: 1px solid var(--border); border-radius: 20px; width: 100%; max-width: 320px; padding: 24px; text-align: center; animation: pop 0.2s ease-out; }
        .modal-content h3 { font-family: 'Outfit'; font-size: 1.1rem; margin-bottom: 8px; }
        .modal-content p { font-size: 0.8rem; color: var(--text-muted); margin-bottom: 20px; }
        .modal-btns { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .m-btn { padding: 12px; border-radius: 10px; border: none; font-weight: 700; font-size: 0.8rem; cursor: pointer; }
        .btn-sec { background: #222; color: #fff; }
        .btn-danger { background: var(--error); color: #fff; }
        .btn-white { background: #fff; color: #000; }

        /* Toast Notification */
        #toast { position: fixed; bottom: 85px; left: 50%; transform: translateX(-50%); background: #fff; color: #000; padding: 10px 20px; border-radius: 50px; font-size: 0.8rem; font-weight: 700; z-index: 3000; display: none; box-shadow: 0 10px 20px rgba(0,0,0,0.5); animation: slideUp 0.3s ease; }

        @keyframes pop { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        @keyframes slideUp { from { transform: translate(-50%, 20px); opacity: 0; } to { transform: translate(-50%, 0); opacity: 1; } }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="#" class="logo">
            <img src="https://i.ibb.co/qFghH6M7/file-1733.jpg"> GitFlow
        </a>
        <div class="nav-actions">
            <div class="nav-icon" onclick="location.href='apiweb.html'"><i class="fas fa-plug"></i></div>
            <div class="nav-icon" onclick="openModal('logoutModal')"><i class="fas fa-power-off"></i></div>
        </div>
    </nav>

    <div class="container">
        
        <div class="user-hero">
            <img src="<?php echo $avatar_url; ?>" class="user-pfp">
            <div>
                <h1>Hi, <?php echo htmlspecialchars($first_name); ?></h1>
                <p>GitFlow Management Console</p>
            </div>
        </div>

        <button class="btn-create" onclick="location.href='new_repo.php'">
            <i class="fas fa-plus"></i> CREATE REPOSITORY
        </button>

        <div class="search-container">
            <i class="fas fa-search"></i>
            <input type="text" class="search-input" id="searchInp" placeholder="Search workspace..." onkeyup="searchRepo()">
        </div>

        <div id="repoList">
            <?php foreach($repos as $repo): 
                $updated = date("d M", strtotime($repo['updated_at']));
                $size = round($repo['size']/1024, 1);
            ?>
            <div class="repo-card item" data-name="<?php echo strtolower($repo['name']); ?>">
                <div class="card-content">
                    <div class="repo-info">
                        <span class="repo-name"><?php echo htmlspecialchars($repo['name']); ?></span>
                        <div class="repo-stats">
                            <span class="status-badge <?php echo $repo['private'] ? 'status-pri' : 'status-pub'; ?>">
                                <?php echo $repo['private'] ? 'PRIVATE' : 'PUBLIC'; ?>
                            </span>
                            <span>• <?php echo $updated; ?></span>
                            <span>• <?php echo $size; ?> MB</span>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="manage.php?repo=<?php echo $repo['name']; ?>" class="footer-btn">
                        <i class="fas fa-cog"></i> MANAGE
                    </a>
                    <div class="footer-btn" onclick="confirmDelete('<?php echo $repo['name']; ?>')">
                        <i class="fas fa-trash-alt"></i> DELETE
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div style="text-align:center; padding: 40px; color: #1a1a1a; font-size: 0.7rem; font-weight: 900; letter-spacing: 3px;">
            DEVELOPED BY SASUKE
        </div>
    </div>

    <div class="modal" id="logoutModal">
        <div class="modal-content">
            <h3>Sign Out?</h3>
            <p>Ending your session will require you to login again.</p>
            <div class="modal-btns">
                <button class="m-btn btn-sec" onclick="closeModal('logoutModal')">CANCEL</button>
                <button class="m-btn btn-white" onclick="location.href='logout.php'">LOGOUT</button>
            </div>
        </div>
    </div>

    <div class="modal" id="deleteModal">
        <div class="modal-content">
            <div style="color:var(--error); font-size: 2.5rem; margin-bottom: 15px;"><i class="fas fa-trash-alt"></i></div>
            <h3>Delete Project?</h3>
            <p>You are about to delete <br><b id="delName" style="color:#fff"></b></p>
            <div class="modal-btns">
                <button class="m-btn btn-sec" onclick="closeModal('deleteModal')">CANCEL</button>
                <button class="m-btn btn-danger" id="confirmDelBtn">DELETE</button>
            </div>
        </div>
    </div>

    <div id="toast">Action Successful</div>

    <script>
        function searchRepo() {
            let val = document.getElementById('searchInp').value.toLowerCase();
            let items = document.getElementsByClassName('item');
            for(let i of items) {
                i.style.display = i.getAttribute('data-name').includes(val) ? 'block' : 'none';
            }
        }

        function openModal(id) { document.getElementById(id).style.display = 'flex'; }
        function closeModal(id) { document.getElementById(id).style.display = 'none'; }

        function showToast(msg) {
            let t = document.getElementById('toast');
            t.innerText = msg;
            t.style.display = 'block';
            setTimeout(() => { t.style.display = 'none'; }, 2500);
        }

        function confirmDelete(name) {
            document.getElementById('delName').innerText = name;
            openModal('deleteModal');
            document.getElementById('confirmDelBtn').onclick = function() {
                closeModal('deleteModal');
                showToast("Deleting repository...");
                setTimeout(() => { location.href = 'delete_engine.php?repo=' + name; }, 1500);
            }
        }
    </script>
</body>
</html>