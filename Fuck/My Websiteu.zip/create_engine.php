<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['token'])) {
    echo json_encode(['status' => 'error', 'msg' => 'Session Expired']);
    exit;
}

$token = $_SESSION['token'];
$user_login = $_SESSION['user']['login'];
$repo_name = $_POST['repo_name'] ?? '';
$is_private = isset($_POST['is_private']) ? true : false;

if (empty($repo_name)) {
    echo json_encode(['status' => 'error', 'msg' => 'Repo name is required']);
    exit;
}

// --- STEP 1: CREATE THE REPOSITORY ---
$repo_data = [
    'name' => $repo_name,
    'private' => $is_private,
    'auto_init' => true // README create karega taaki repo empty na rahe
];

$ch = curl_init("https://api.github.com/user/repos");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($repo_data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $token,
    'User-Agent: GitFlow-Pro',
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if ($http_code !== 201) {
    echo json_encode(['status' => 'error', 'msg' => 'Failed to create repo: ' . $response]);
    exit;
}

// --- STEP 2: UPLOAD FILES (IF ANY) ---
if (isset($_FILES['user_files']) && !empty($_FILES['user_files']['name'][0])) {
    $files = $_FILES['user_files'];
    
    foreach ($files['tmp_name'] as $key => $tmp_name) {
        if ($files['error'][$key] === 0) {
            $file_name = $files['name'][$key];
            $file_content = base64_encode(file_get_contents($tmp_name));
            
            // GitHub API Content Upload URL
            $upload_url = "https://api.github.com/repos/$user_login/$repo_name/contents/$file_name";
            
            $upload_data = [
                'message' => "Initial commit: $file_name via GitFlow",
                'content' => $file_content
            ];

            $ch_up = curl_init($upload_url);
            curl_setopt($ch_up, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch_up, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($ch_up, CURLOPT_POSTFIELDS, json_encode($upload_data));
            curl_setopt($ch_up, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $token,
                'User-Agent: GitFlow-Pro',
                'Content-Type: application/json'
            ]);
            curl_setopt($ch_up, CURLOPT_SSL_VERIFYPEER, false);
            
            curl_exec($ch_up);
            curl_close($ch_up);
        }
    }
}

// --- STEP 3: SUCCESS REDIRECT ---
header("Location: dashboard.php?status=success&msg=Repo Created & Deployed!");
exit;
?>